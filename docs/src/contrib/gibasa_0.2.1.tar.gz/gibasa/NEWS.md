# gibasa 0.2.1

* `prettify` now can extract columns only specified by `col_select`.

# gibasa 0.2.0

* Added a `NEWS.md` file to track changes to the package.
* `tokenize` now gets a data.frame as its first argument, returns a data.frame only. The former function that gets character vector and returns a data.frame or named list was renamed as `gbs_tokenize`.
