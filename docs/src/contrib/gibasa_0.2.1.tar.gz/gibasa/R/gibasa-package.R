#' @keywords internal
#' @import Rcpp
#' @importFrom RcppParallel RcppParallelLibs
#' @importFrom rlang enquo enquos .data := as_name as_label
#' @importFrom dplyr %>%
#' @useDynLib gibasa, .registration = TRUE
"_PACKAGE"
