library(testthat)
library(RcppMeCab)
library(purrr)

test_check("RcppMeCab")
